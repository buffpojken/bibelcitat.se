<?php
require_once('widget-ad300x250.php');
require_once('widget-rayoflight-last-articles.php');
require_once('widget-rayoflight-spacer.php');
require_once('widget-rayoflight-triple-box.php');
require_once('widget-rayoflight-gallery.php');
?>