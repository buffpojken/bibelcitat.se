<?php
	require_once('buttons.php');
	require_once('gallery-box.php');
	require_once('layouts.php');
	require_once('lists.php');
	require_once('qoutes.php');
	require_once('spacers.php');
?>