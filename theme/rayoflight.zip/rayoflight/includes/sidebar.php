<!-- BEGIN .right-side -->
<div class="right-side">
	
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar Home") ) : ?>
	<?php endif; ?>

<!-- END .right-side -->
</div>

<!-- END .content -->
</div>

<!-- END .content-wrapper -->
</div>