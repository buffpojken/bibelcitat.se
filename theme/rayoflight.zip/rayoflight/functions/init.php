<?php
require_once('register.php');
require_once('filters.php');
require_once('thumbs.php');
require_once('nav.php');
require_once('other.php');
require_once('rayoflight_menu.php');
?>