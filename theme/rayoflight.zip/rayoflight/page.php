<?php get_header(); ?>
<?php //remove_all_shortcodes(); ?>
<?php include (THEME_INCLUDES . '/top.php'); ?>
<?php include (THEME_INCLUDES . '/page_single.php'); ?>
<?php include (THEME_INCLUDES . '/sidebar.php'); ?>
<?php get_footer(); ?>